Delete a Cluster Parameter Group
--------------------------------

This example deletes a cluster parameter group.

Command::

   aws redshift delete-cluster-parameter-group --parameter-group-name myclusterparametergroup

