**To delete a compute environment**

This example deletes the `P2OnDemand` compute environment.

Command::

  aws batch delete-compute-environment --compute-environment P2OnDemand
